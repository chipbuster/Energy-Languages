/*
 * Copyright 2004-2017 Cray Inc.
 * Other additional copyright holders may be indicated within.
 *
 * The entirety of this work is licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 *
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include "optimizations.h"

#include "astutil.h"
#include "bb.h"
#include "expr.h"
#include "ForLoop.h"
#include "passes.h"
#include "stlUtil.h"
#include "stmt.h"
#include "WhileStmt.h"
#include "ForLoop.h"

#include <queue>
#include <set>

typedef std::set<BasicBlock*> BasicBlockSet;

static void deadBlockElimination(FnSymbol* fn);
static void findReachableBlocks(FnSymbol* fn, BasicBlockSet& reachable);
static void deleteUnreachableBlocks(FnSymbol* fn, BasicBlockSet& reachable);
static bool         isInCForLoopHeader(Expr* expr);
static void         cleanupLoopBlocks(FnSymbol* fn);

static unsigned int deadBlockCount;
static unsigned int deadModuleCount;



//
//
// 2014/10/17 TO DO Noakes/Elliot
//
// There are opportunities to do additional cleanup of the AST e.g.
//
// remove blockStmts with empty bodies
// remove condStmts  with empty bodies
// remove jumps to labels that immmediately follow
//
// This may require multiple passes to converge e.g.
//
// A block statement that contains an empty block statement
//
// An empty cond statement between a goto and the target of the goto
//
//

//
// Removes local variables that are only targets for moves, but are
// never used anywhere.
//
static bool isDeadVariable(Symbol* var) {
  if (var->isRef()) {
    // is it defined more than once?
    int ndefs = var->countDefs(/*max*/ 2);
    return (!var->isUsed()) && (ndefs <= 1);
  } else {
    return !var->isUsed();
  }
}

void deadVariableElimination(FnSymbol* fn) {
  Vec<Symbol*> symSet;
  collectSymbolSet(fn, symSet);

  forv_Vec(Symbol, sym, symSet)
  {
    // We're interested only in VarSymbols.
    if (!isVarSymbol(sym))
      continue;

    // A method must have a _this symbol, even if it is not used.
    if (sym == fn->_this)
      continue;

    if (isDeadVariable(sym)) {
      for_SymbolDefs(se, sym) {
        CallExpr* call = toCallExpr(se->parentExpr);
        //INT_ASSERT(call &&
        //           (call->isPrimitive(PRIM_MOVE) ||
        //            call->isPrimitive(PRIM_ASSIGN)));
        //Expr* rhs = call->get(2)->remove();
        INT_ASSERT(call);
        Expr* dest = NULL;
        Expr* rhs = NULL;
        bool ok = getSettingPrimitiveDstSrc(call, &dest, &rhs);
        INT_ASSERT(ok);
        rhs->remove();
        if (!isSymExpr(rhs))
          call->replace(rhs);
        else
          call->remove();
      }
      sym->defPoint->remove();
    }
  }
}

//
// Removes expression statements that have no effect.
//
void deadExpressionElimination(FnSymbol* fn) {
  std::vector<BaseAST*> asts;

  collect_asts(fn, asts);

  for_vector(BaseAST, ast, asts) {
    Expr* exprAst = toExpr(ast);

    if (exprAst == 0) {

    } else if (isAlive(exprAst) == false) {

    } else if (SymExpr* expr = toSymExpr(ast)) {
      if (expr->isStmtExpr() == true && isInCForLoopHeader(expr) == false) {
        expr->remove();
      }

    } else if (CallExpr* expr = toCallExpr(ast)) {
      if (expr->isPrimitive(PRIM_CAST) ||
          expr->isPrimitive(PRIM_GET_MEMBER_VALUE) ||
          expr->isPrimitive(PRIM_GET_MEMBER) ||
          expr->isPrimitive(PRIM_DEREF) ||
          expr->isPrimitive(PRIM_ARRAY_GET) ||
          expr->isPrimitive(PRIM_ADDR_OF) ||
          expr->isPrimitive(PRIM_SET_REFERENCE)) {
        if (expr->isStmtExpr())
          expr->remove();
      }

      if (expr->isPrimitive(PRIM_MOVE) ||
          expr->isPrimitive(PRIM_ASSIGN))
        if (SymExpr* lhs = toSymExpr(expr->get(1)))
          if (SymExpr* rhs = toSymExpr(expr->get(2)))
            if (lhs->symbol() == rhs->symbol())
              expr->remove();

    } else if (CondStmt* cond = toCondStmt(ast)) {
      // Compensate for deadBlockElimination
      if (cond->condExpr == NULL) {
        cond->remove();

      } else if (cond->thenStmt == NULL && cond->elseStmt == NULL) {
        cond->remove();

      } else {

        // Invert the condition and shuffle the alternative
        if (cond->thenStmt == NULL) {
          Expr* condExpr = new CallExpr(PRIM_UNARY_LNOT, cond->condExpr);

          cond->replaceChild(cond->condExpr, condExpr);
          cond->replaceChild(cond->thenStmt, cond->elseStmt);
          cond->replaceChild(cond->elseStmt, NULL);

        // NOAKES 2014/11/14 It's "odd" that folding is being done here
        } else {
          cond->foldConstantCondition();
        }

        // NOAKES 2014/11/14 Testing suggests this is always a NOP
        removeDeadIterResumeGotos();
      }
    }
  }
}

static bool isInCForLoopHeader(Expr* expr) {
  Expr* stmtExpr = expr->parentExpr;
  bool  retval   = false;

  if (BlockStmt* blockStmt = toBlockStmt(stmtExpr)) {
    retval = (blockStmt->blockTag == BLOCK_C_FOR_LOOP) ? true : false;
  }

  return retval;
}

void deadCodeElimination(FnSymbol* fn) {
  std::map<SymExpr*, Vec<SymExpr*>*> DU;
  std::map<SymExpr*, Vec<SymExpr*>*> UD;

  std::map<Expr*,    Expr*>          exprMap;

  Vec<Expr*>                         liveCode;
  Vec<Expr*>                         workSet;

  BasicBlock::buildBasicBlocks(fn);

  buildDefUseChains(fn, DU, UD);

  for_vector(BasicBlock, bb, *fn->basicBlocks) {
    for (size_t i = 0; i < bb->exprs.size(); i++) {
      Expr*         expr        = bb->exprs[i];
      bool          isEssential = bb->marks[i];

      std::vector<BaseAST*> asts;

      collect_asts(expr, asts);

      for_vector(BaseAST, ast, asts) {
        if (Expr* sub = toExpr(ast)) {
          exprMap[sub] = expr;
        }
      }

      if (isEssential == false) {
        for_vector(BaseAST, ast, asts) {
          if (CallExpr* call = toCallExpr(ast)) {
            // mark assignments to global variables as essential
            if (call->isPrimitive(PRIM_MOVE) || call->isPrimitive(PRIM_ASSIGN)) {
              if (SymExpr* se = toSymExpr(call->get(1))) {
                if (DU.count(se) == 0) {
                  isEssential = true;
                }
              }
            }
          }
        }
      }

      if (isEssential) {
        liveCode.set_add(expr);
        workSet.add(expr);
      }
    }
  }

  forv_Vec(Expr, expr, workSet) {
    std::vector<SymExpr*> symExprs;

    collectSymExprs(expr, symExprs);

    for_vector(SymExpr, se, symExprs) {
      if (UD.count(se) != 0) {
        Vec<SymExpr*>* defs = UD[se];

        forv_Vec(SymExpr, def, *defs) {
          INT_ASSERT(exprMap.count(def) != 0);

          Expr* expr = exprMap[def];

          if (!liveCode.set_in(expr)) {
            liveCode.set_add(expr);
            workSet.add(expr);
          }
        }
      }
    }
  }

  // This removes dead expressions from each block.
  for_vector(BasicBlock, bb1, *fn->basicBlocks) {
    for_vector(Expr, expr, bb1->exprs) {
      if (isSymExpr(expr) || isCallExpr(expr))
        if (!liveCode.set_in(expr))
          expr->remove();
    }
  }

  freeDefUseChains(DU, UD);
}

/************************************* | **************************************
*                                                                             *
*                      Eliminate dead string literals.                        *
*                                                                             *
* String literals are created by new_StringSymbol().  This includes strings   *
* used internally by the compiler (e.g. "boundedNone" for BoundedRangeType)   *
* and param string used for things like compiler error messages as well as    *
* strings that may be used at runtime.                                        *
*                                                                             *
* new_StringSymbol() adds all strings to stringLiteralModule, but strings     *
* that are only used for compilation or whose runtime path was param folded   *
* away are never removed because the code paths that are removed don't        *
* include the string literal initialization.                                  *
*                                                                             *
* There are three components to removing a dead string literal                *
*                                                                             *
*   1) Identifying that a literal is dead.                                    *
*                                                                             *
*      This relies on details of def-use analysis and of the code that        *
*      initializes string literals.  Both of these may change.                *
*                                                                             *
*   2) Remove the module level DefExpr.                                       *
*                                                                             *
*      This is easy.                                                          *
*                                                                             *
*   3) Remove the code that initializes the literal.                          *
*                                                                             *
*      This is fragile as it currently depends on implementation details in   *
*      other portions of the compiler.  It is believed that this will be      *
*      easier to manage when record initializers are in production.           *
*                                                                             *
* The hardest part is determining when this code needs to be revisited.       *
* 2017/03/04: Perform an "ad hoc" sanity check for now.                       *
* 2017/03/09: Disable this pass if flags might alter the pattern.             *
*                                                                             *
************************************** | *************************************/

static bool isDeadStringLiteral(VarSymbol* string);
static void removeDeadStringLiteral(DefExpr* defExpr);

static void deadStringLiteralElimination() {
  // Noakes 2017/03/09
  //   These two flags are known to alter the pattern we are looking for.
  //   Rather than handle the variations we simply leak if these flags are
  //   on.  We anticipate that this will be easier to handle when record
  //   initializers are in production and have been applied to strings.
  if (fNoCopyPropagation == false &&
      fNoInline          == false) {
    int numStmt        = 0;
    int numDeadLiteral = 0;

    for_alist(stmt, stringLiteralModule->block->body) {
      numStmt = numStmt + 1;

      if (DefExpr* defExpr = toDefExpr(stmt)) {
        if (VarSymbol* symbol = toVarSymbol(defExpr->sym)) {
          if (isDeadStringLiteral(symbol) == true) {
            removeDeadStringLiteral(defExpr);

            numDeadLiteral = numDeadLiteral + 1;
          }
        }
      }
    }

    //
    // Noakes 2017/03/04
    //
    // There is not a principled way to determine if other passes
    // have changed in a way that would confuse this pass.
    //
    // A quick review of a portion of test/release/examles shows that
    // this pass removes 85 - 95% of the string literals.  Signal an
    // error if this pass doesn't reclaim at least 10% of all string
    // literals unless this is minimal modules
    //
    if (fMinimalModules == false) {
      INT_ASSERT((1.0 * numDeadLiteral) / numStmt > 0.10);
    }
  }
}

// Noakes 2017/03/04: All literals have 1 def. Dead literals have 0 uses.
static bool isDeadStringLiteral(VarSymbol* string) {
  bool retval = false;

  if (string->hasFlag(FLAG_CHAPEL_STRING_LITERAL) == true) {
    int numDefs = string->countDefs();
    int numUses = string->countUses();

    retval = numDefs == 1 && numUses == 0;

    INT_ASSERT(numDefs == 1);
  }

  return retval;
}

//
// Noakes 2017/03/04
//
// The current pattern to initialize a string literal is approximately
//
//   var  call_tmp : c_ptr;
//
//   move call_tmp, cast(c_ptr(uint(8)), c"literal string")
//
//   var  ret_tmp  : string;
//   ref  ref_tmp  : string;
//
//   move ref_tmp,  addrOf(ret_tmp);
//
//   _construct_string(call_tmp, ... , ref_tmp);
//
//   move the_str,  ret_tmp       // This is the single def
//

static void removeDeadStringLiteral(DefExpr* defExpr) {
  SymExpr*   defn  = toVarSymbol(defExpr->sym)->getSingleDef();

  // Step backwards from the def of 'the_str'
  Expr*      stmt7 = defn->getStmtExpr();         // move the_str, ret_tmp
  Expr*      stmt6 = stmt7 ? stmt7->prev : NULL;  // _construct_string
  Expr*      stmt5 = stmt6 ? stmt6->prev : NULL;  // move ref_tmp, addrOf(..)
  Expr*      stmt4 = stmt5 ? stmt5->prev : NULL;  // ref  ref_tmp
  Expr*      stmt3 = stmt4 ? stmt4->prev : NULL;  // var  ret_tmp
  Expr*      stmt2 = stmt3 ? stmt3->prev : NULL;  // move call_tmp, cast(..)
  Expr*      stmt1 = stmt2 ? stmt2->prev : NULL;  // var  call_tmp

  // Simple sanity checks
  INT_ASSERT(isDefExpr (stmt1));
  INT_ASSERT(isCallExpr(stmt2));
  INT_ASSERT(isDefExpr (stmt3));
  INT_ASSERT(isDefExpr (stmt4));
  INT_ASSERT(isCallExpr(stmt5));
  INT_ASSERT(isCallExpr(stmt6));
  INT_ASSERT(isCallExpr(stmt7));

  stmt7->remove();
  stmt6->remove();
  stmt5->remove();
  stmt4->remove();
  stmt3->remove();
  stmt2->remove();
  stmt1->remove();

  defExpr->remove();
}

/************************************* | **************************************
*                                                                             *
*                                                                             *
*                                                                             *
************************************** | *************************************/

// Determines if a module is dead. A module is dead if the module's init
// function can only be called from module code, and the init function
// is empty, and the init function is the only thing in the module, and the
// module is not a nested module.
static bool isDeadModule(ModuleSymbol* mod) {
  // The main module and any module whose init function is exported
  // should never be considered dead, as the init function can be
  // explicitly called from the runtime, or other c code
  if (mod == mainModule || mod->hasFlag(FLAG_EXPORT_INIT)) return false;

  // because of the way modules are initialized, we don't want to consider a
  // nested function as dead as its outer module and all of its uses should
  // have their initializer called by the inner module.
  if (mod->defPoint->getModule() != theProgram &&
      mod->defPoint->getModule() != rootModule)
    return false;

  // if there is only one thing in the module
  if (mod->block->body.length == 1) {
    if (!mod->initFn) {
      // Prevents a segfault experienced when cleaning up a module which has
      // only an inner module defined in it (and neither have an init function)
      INT_FATAL("Expected initFn for module '%s', but was null", mod->name);
    }

    // and that thing is the init function
    if (mod->block->body.only() == mod->initFn->defPoint) {
      // and the init function is empty (only has a return)
      if (mod->initFn->body->body.length == 1) {
        // then the module is dead
        return true;
      }
    }
  }
  return false;
}


// Eliminates all dead modules
static void deadModuleElimination() {
  deadModuleCount = 0;
  forv_Vec(ModuleSymbol, mod, allModules) {
    if (isDeadModule(mod) == true) {
      deadModuleCount++;

      // remove the dead module and its initFn
      mod->defPoint->remove();
      mod->initFn->defPoint->remove();

      // Inform every module about the dead module
      forv_Vec(ModuleSymbol, modThatMightUse, allModules) {
        if (modThatMightUse != mod) {
          modThatMightUse->moduleUseRemove(mod);
        }
      }
    }
  }
}

void deadCodeElimination() {
  if (!fNoDeadCodeElimination) {
    deadBlockElimination();

    deadStringLiteralElimination();


    forv_Vec(FnSymbol, fn, gFnSymbols) {

      // 2014/10/17   Noakes and Elliot
      // Dead Block Elimination may convert valid loops to "malformed" loops.
      // Some of these will break BasicBlock construction. Clean them up.
      cleanupLoopBlocks(fn);

      deadCodeElimination(fn);

      deadVariableElimination(fn);

      // 2014/10/17   Noakes and Elliot
      // Dead Variable Elimination may convert some "uninteresting" loops
      // that were left behind by DeadBlockElimination and turn them in to
      // "malformed" loops.  Cleanup again.
      cleanupLoopBlocks(fn);

      deadExpressionElimination(fn);
    }

    deadModuleElimination();

    if (fReportDeadModules)
      printf("Removed %d dead modules.\n", deadModuleCount);
  }
}

void deadBlockElimination()
{
  deadBlockCount = 0;

  forv_Vec(FnSymbol, fn, gFnSymbols)
  {
    if (!isAlive(fn))
      continue;
    deadBlockElimination(fn);
  }

  if (fReportDeadBlocks)
    printf("\tRemoved %d dead blocks.\n", deadBlockCount);

}

// Look for and remove unreachable blocks.
static void deadBlockElimination(FnSymbol* fn)
{
  // We need the basic block information to be correct, so recompute it.
  BasicBlock::buildBasicBlocks(fn);

  // Find the reachable basic blocks within this function.
  BasicBlockSet reachable;

  findReachableBlocks(fn, reachable);
  deleteUnreachableBlocks(fn, reachable);
}

// Muchnick says we can enumerate the unreachable blocks first and then just
// remove them.  We only need to do this once, because removal of an
// unreachable block cannot possibly make any reachable block unreachable.
static void findReachableBlocks(FnSymbol* fn, BasicBlockSet& reachable)
{
  // We set up a work queue to perform a BFS on reachable blocks, and seed it
  // with the first block in the function.
  std::queue<BasicBlock*> work_queue;

  INT_ASSERT(fn->basicBlocks);
  INT_ASSERT(fn->basicBlocks->size() > 0);
  work_queue.push((*fn->basicBlocks)[0]);

  // Then we iterate until there are no more blocks to visit.
  while (!work_queue.empty())
  {
    // Fetch and remove the next block.
    BasicBlock* bb = work_queue.front();

    work_queue.pop();

    // Ignore it if we've already seen it.
    if (reachable.count(bb))
      continue;

    // Otherwise, mark it as reachable, and append all of its successors to the
    // work queue.
    reachable.insert(bb);

    for_vector(BasicBlock, out, bb->outs)
      work_queue.push(out);
  }
}

static void deleteUnreachableBlocks(FnSymbol* fn, BasicBlockSet& reachable)
{
  // Visit all the blocks, deleting all those that are not reachable
  for_vector(BasicBlock, bb, *fn->basicBlocks)
  {
    if (reachable.count(bb))
      continue;

    ++deadBlockCount;

    // Remove all of its expressions.
    for_vector(Expr, expr, bb->exprs)
    {
      if (! expr->parentExpr)
        continue;   // This node is no longer in the tree.

      // Do not remove def expressions (for now)
      // In some cases (associated with iterator code), defs appear in dead
      // blocks but are used in later blocks, so removing the defs results
      // in a verify error.
      // TODO: Perhaps this reformulation of unreachable block removal does a better
      // job and those blocks are now removed as well.  If so, this IF can be removed.
      if (toDefExpr(expr))
        continue;

      CondStmt*  condStmt  = toCondStmt(expr->parentExpr);
      WhileStmt* whileStmt = toWhileStmt(expr->parentExpr);
      ForLoop*   forLoop   = toForLoop(expr->parentExpr);

      if (condStmt && condStmt->condExpr == expr)
        // If the expr is the condition expression of an if statement,
        // then remove the entire if. (NOTE 1)
        condStmt->remove();

      else if (whileStmt && whileStmt->condExprGet() == expr)
        // If the expr is the condition expression of a while statement,
        // then remove the entire While. (NOTE 1)
        whileStmt->remove();

      else if (forLoop   && forLoop->indexGet()      == expr)
        // Do nothing. (NOTE 2)
        ;

      else if (forLoop   && forLoop->iteratorGet()   == expr)
        // Do nothing. (NOTE 2)
        ;

      else
        expr->remove();
    }
  }
}

//
// See if any iterator resume labels have been remove (and not re-inserted).
// If so, remove the matching gotos, if they haven't been yet.
//
void removeDeadIterResumeGotos() {
  forv_Vec(LabelSymbol, labsym, removedIterResumeLabels) {
    if (!isAlive(labsym) && isAlive(labsym->iterResumeGoto))
      labsym->iterResumeGoto->remove();
  }
  removedIterResumeLabels.clear();
}

//
// Make sure there are no iterResumeGotos to remove.
// Reset removedIterResumeLabels.
//
void verifyRemovedIterResumeGotos() {
  forv_Vec(LabelSymbol, labsym, removedIterResumeLabels) {
    if (!isAlive(labsym) && isAlive(labsym->iterResumeGoto))
      INT_FATAL("unexpected live goto for a dead removedIterResumeLabels label - missing a call to removeDeadIterResumeGotos?");
  }
}

// 2014/10/15
//
// Dead Block elimination can create at least two forms of mal-formed AST
//
// A valid ForLoop can be transformed in to
//
//              for ( ; ; ) {
//              }
//
// and a valid WhileLoop can be transformed in to
//
//              while ( ) {
//              }
//
// The C standard defines these as infinite loops.  In practice the
// Chapel compiler will only leave these ASTs in unreachable code and
// so these wouldn't lead to runtime failures but each of these forms
// cause problems in the compiler down stream from here.
//
// 2014/10/17
//
// Additionally DBE can create loops that are similar to the above but
// that include some number of DefExprs (there is currently code in DBE
// to prevent it removing DefExprs for reasons that are partially but
// not fully understood).  These loops will be converted to the former
// case during DeadVariableElimination
//

static void cleanupLoopBlocks(FnSymbol* fn) {
  std::vector<Expr*> stmts;

  collect_stmts(fn->body, stmts);

  for_vector (Expr, expr, stmts) {
    if (BlockStmt* stmt = toBlockStmt(expr)) {
      stmt->deadBlockCleanup();
    }
  }
}

// Look for pointless gotos and remove them.
// Probably the best way to do this is to scan the AST and remove gotos
// whose target labels follow immediately.
#if 0
static void deadGotoElimination(FnSymbol* fn)
{
  // We recompute basic blocks because deadBlockElimination may cause them
  // to be out of sequence.
  buildBasicBlocks(fn);
  forv_Vec(BasicBlock, bb, *fn->basicBlocks)
  {
    // Get the last expression in the block as a goto.
    int last = bb->exprs.length() - 1;
    if (last < 0)
      continue;

    Expr* e = bb->exprs.v[last];
    GotoStmt* s = toGotoStmt(e);
    if (!s)
      continue;

    // If there is only one successor to this block and it is the next block,
    // then the goto must point to it and is therefore pointless [sts].
    // This test should be more foolproof using the structure of the AST.
    if (bb->outs.n == 1 && bb->outs.v[0]->id == bb->id + 1)
      e->remove();
  }
}
#endif

//########################################################################
//# NOTES
//#
//# 1. This cleanup is not really part of dead block removal, but is necessary
//#    to avoid leaving the AST in a malformed state.  A more-factored approach
//#    would be to have a cleanup function that can be invoked on parts of the
//#    tree to normalize AST constructs that have been partially eviscerated.
//#
//#    This particular traversal should probably be done in postorder.  Then,
//#    the check at the top of the loop can be eliminated additional checks can
//#    be added to ensure that when a construct is to be removed, all of its
//#    constituent parts have already been removed from the tree.
//#
//# 2. Because the ForLoop construct contains initialization code, we cannot
//#    necessarily remove the entire for loop when we discover that evaluation
//#    of the iterator index is dead.  (It's probably a safer bet when the
//#    iterator expression is dead.)
//#
