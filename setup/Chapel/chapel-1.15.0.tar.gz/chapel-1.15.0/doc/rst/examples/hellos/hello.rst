.. default-domain:: chpl

.. _primers-hello:

Simple hello world
==================

`View hello.chpl on GitHub <https://github.com/chapel-lang/chapel/blob/master/test/release/examples/hello.chpl>`_


.. code-block:: chapel

    writeln("Hello, world!");    // print 'Hello, world!' to the console