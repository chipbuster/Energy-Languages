.. _chapel-spec:

Chapel Language Specification
=============================

:download:`View Language Specification [pdf] <chapelLanguageSpec.pdf>`

To see language specifications of previous versions, see :ref:`Archived Languages Specifications<chapel-archived-specs>`.
